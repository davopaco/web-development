export interface SaveInterface{
    email: string;
    contenido: string;
    id?: string;
}